Nicholas Grant
ECE473
Lab 5
		

ReadMe

In this lab, we created a register file and programmed it onto the board.
We then created 1-Port RAM and ROM, and read from both data memory and
instruction memory to the board. We displayed these values on and LCD, 
and hex displays, and controlled them with switches and push buttons. 

In addition, we used pipeline registers to execute an add using the register
file and memory already in place.

